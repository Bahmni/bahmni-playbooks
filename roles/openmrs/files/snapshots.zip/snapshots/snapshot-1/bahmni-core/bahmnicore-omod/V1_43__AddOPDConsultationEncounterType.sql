INSERT INTO encounter_type (name, description, creator, date_created, uuid) VALUES ('OPD', 'OPD consultation encounter', 1, curdate(), uuid());
