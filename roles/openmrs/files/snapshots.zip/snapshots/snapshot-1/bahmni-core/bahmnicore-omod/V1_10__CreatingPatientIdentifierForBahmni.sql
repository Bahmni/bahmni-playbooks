INSERT INTO patient_identifier_type (name, description, creator, date_created, required, uuid, location_behavior)
  VALUES ('JSS', 'New patient identifier type created for use by the Bahmni Registration System', 1, curdate(), 1, uuid(), 'NOT_USED');
