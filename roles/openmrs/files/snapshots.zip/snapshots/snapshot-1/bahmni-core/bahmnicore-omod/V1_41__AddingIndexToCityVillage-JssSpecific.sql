-- JSS specific
CREATE INDEX person_address_city_village ON person_address (city_village);